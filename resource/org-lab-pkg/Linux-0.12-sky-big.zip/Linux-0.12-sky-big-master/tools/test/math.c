#include <stdio.h>

int main(int argc, char *argv[]) {

    float i = 2.2;
    printf("%s", i);
    return (0);
}