Ref:

* <http://www.oldlinux.org/>
* <http://www.oldlinux.org/download/clk011c-3.0.pdf>
