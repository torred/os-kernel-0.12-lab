#!/bin/bash
$BOCHS_HOME/bin/bochs-gdb -f $OS_LAB_ENV/bochs/bochs-gdb.rc -q

