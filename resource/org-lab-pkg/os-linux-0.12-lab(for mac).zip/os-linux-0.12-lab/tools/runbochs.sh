#!/bin/bash
$BOCHS_HOME/bin/bochs -f $OS_LAB_ENV/bochs/bochs.rc -q

